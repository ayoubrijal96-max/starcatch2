# 📘 Guide complet — Mettre StarCatch en ligne sur GitHub et gagner de l'argent

---

## ÉTAPE 1 — Créer un compte GitHub (5 min)

1. Va sur https://github.com
2. Clique sur **"Sign up"** (en haut à droite)
3. Entre :
   - Une adresse email
   - Un mot de passe
   - Un nom d'utilisateur (ex: `starcatch-game` ou ton prénom)
4. Vérifie ton email (GitHub envoie un code)
5. Connecte-toi

---

## ÉTAPE 2 — Créer le dépôt (repository) (3 min)

1. Une fois connecté, clique sur le **"+"** en haut à droite → **"New repository"**
2. Remplis :
   - **Repository name** : `starcatch`
   - **Description** : `Jeu arcade gratuit en ligne`
   - Coche **"Public"** (obligatoire pour GitHub Pages gratuit)
   - Coche **"Add a README file"**
3. Clique **"Create repository"**

---

## ÉTAPE 3 — Uploader tous les fichiers (5 min)

1. Sur la page de ton dépôt, clique **"Add file"** → **"Upload files"**
2. Glisse-dépose ces 4 fichiers en même temps :
   - `index.html`
   - `privacy.html`
   - `mentions-legales.html`
   - `contact.html`
3. En bas, dans le champ **"Commit changes"**, laisse le message par défaut
4. Clique **"Commit changes"**

---

## ÉTAPE 4 — Activer GitHub Pages (2 min)

1. Va dans l'onglet **"Settings"** (en haut de ton dépôt)
2. Dans le menu de gauche, clique **"Pages"**
3. Sous **"Branch"**, clique le menu déroulant → sélectionne **"main"**
4. Clique **"Save"**
5. **Attends 2-3 minutes**
6. Rafraîchis la page → tu verras :
   `✅ Your site is live at https://TON-PSEUDO.github.io/starcatch`

🎉 Ton site est en ligne !

---

## ÉTAPE 5 — Créer un compte Google AdSense (15 min)

1. Va sur https://adsense.google.com
2. Connecte-toi avec un compte Google
3. Clique **"Commencer"**
4. Renseigne l'URL de ton site : `https://TON-PSEUDO.github.io/starcatch`
5. Choisis ton pays → **France**
6. Accepte les conditions d'utilisation
7. Clique **"Démarrer avec AdSense"**

### Ajouter le code de vérification AdSense à ton site
AdSense te donnera un petit bout de code à coller dans ton `index.html`.
Il ressemble à ça :
```html
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-1234567890123456" crossorigin="anonymous"></script>
```

Pour l'ajouter :
1. Sur GitHub, ouvre ton fichier `index.html`
2. Clique sur l'icône **crayon** (modifier)
3. Colle le code juste après la ligne `<meta name="keywords"...>`
4. Clique **"Commit changes"**
5. Retourne sur AdSense et clique **"Vérifier"**

### Délai d'approbation
⏳ Google vérifie ton site et t'envoie un email sous **1 à 14 jours**.
Pendant ce temps, continue à partager ton lien !

---

## ÉTAPE 6 — Activer les vraies pubs (après approbation)

Une fois que tu reçois l'email "Félicitations, votre site est approuvé" :

1. Dans AdSense, va dans **"Annonces"** → **"Par unité d'annonce"**
2. Crée 3 blocs publicitaires :
   - **Leaderboard** 728×90 → pour le haut de page
   - **Rectangle** 300×250 → pour la sidebar (crée-en 2)
   - **Banner** 728×60 → sous le jeu
3. Pour chaque bloc, AdSense te donne un code. Note les **`data-ad-slot`** de chacun.

4. Ouvre `index.html` sur GitHub (crayon pour modifier)
5. Remplace `ca-pub-XXXXXXXXXX` par ton vrai ID partout (Ctrl+F pour trouver)
6. Pour chaque bloc pub, **retire les `<!--` et `-->`** autour du code AdSense
7. **Supprime** les lignes `<span>📢 Espace publicitaire...</span>` de remplacement
8. Commit les changements

---

## ÉTAPE 7 — Attirer des visiteurs (CRUCIAL)

Sans visiteurs = 0 €. Voici quoi faire dès aujourd'hui :

### Aujourd'hui (gratuit, 30 min)
- [ ] Poste le lien sur tes réseaux sociaux personnels
- [ ] Envoie le lien à tes amis et famille
- [ ] Poste sur Reddit : https://reddit.com/r/WebGames (en anglais)
- [ ] Poste sur Reddit : https://reddit.com/r/indiegaming

### Cette semaine
- [ ] Crée un compte sur https://itch.io et publie le jeu (gratuit)
- [ ] Poste dans des groupes Facebook "Jeux en ligne gratuits"
- [ ] Crée un TikTok en te filmant jouer et mets le lien en bio

### Ce mois-ci
- [ ] Ajoute un 2ème jeu sur le site → plus de pages = plus de trafic
- [ ] Ajoute un blog avec des articles ("jeux gratuits en ligne", "meilleur score")

---

## Estimation des revenus réels

| Visiteurs / jour | Revenus / mois |
|-----------------|----------------|
| 50              | 0,10 – 0,50 €  |
| 500             | 1 – 5 €        |
| 5 000           | 10 – 50 €      |
| 50 000          | 100 – 500 €    |
| 500 000         | 1 000 – 5 000 €|

**La clé : plus de jeux + plus de partage = plus de visiteurs = plus d'argent.**

---

## Récapitulatif des fichiers à uploader sur GitHub

```
starcatch/
├── index.html          ← Le jeu principal ✅
├── privacy.html        ← Politique de confidentialité ✅ (obligatoire AdSense)
├── mentions-legales.html ← Mentions légales ✅ (obligatoire en France)
└── contact.html        ← Page contact ✅ (obligatoire AdSense)
```

---

## Liens utiles

| Service | Lien | Pour quoi ? |
|---------|------|-------------|
| GitHub | https://github.com | Héberger le site |
| Google AdSense | https://adsense.google.com | Gagner de l'argent |
| Itch.io | https://itch.io | Publier le jeu |
| Formspree | https://formspree.io | Recevoir les emails contact |
| Google Analytics | https://analytics.google.com | Voir tes visiteurs |

---

*Guide créé avec Claude — Anthropic*
